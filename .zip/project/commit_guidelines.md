commit guidelines
whitespace errors      
